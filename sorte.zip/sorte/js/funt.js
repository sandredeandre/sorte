function startJS() {
	xhrequest=null;
	try{
		xhrequest=getXMLHttpRequest();

	}
	catch(error){
		document.write("Ops, não suporta, o conjunto de tecnologia este navegador");
	}
	if (xhrequest!=null) {
		//obter valores 
		var doform=document.getElementsById('idquecoloqueino  submit').value;
		var outradoinput="pagina phpcom acçao"+idquecoloqueino  submit;

		xhrequest.onreadystatchange=changePage;
		xhrequest.open("POST",outradoinput, true);
		xhrequest.send(null);

	}
}
// função status do servidor 
function statusServer(){
	if (xhrequest.readyState==4 && xhrequest.status==200) {
var resposta= xhrequest.responseText;
document.getElementsById("iddarespostanapagina").innerHTML=resposta;

	}
}
tipo de estado da resposta 
0: not initialized.
1: connection established.
2: request received.
3: answer in process.
4: finished.
//funçao resposta do servidor 
function respostaServer(){
// If IE7, Mozilla, Safari, etc: Use native object
try {
	xhrequest= new XMLHttpRequest();
	return xhrequest;
}
catch(exception){
 //ok, just 
	}
}else {
// ...otherwise, use the ActiveX control for IE5.x and IE6
var IEControls = ["MSXML2.XMLHttp.5.0","MSXML2.XMLHttp.4.0",
"MSXML2.XMLHttp.3.0","MSXML2.XMLHttp"];
for(var i=0; i<IEControls.length; i++) {
try {
xhrequest = new ActiveXObject(IEControls[i]);
getxmlhttprequest.js
return xhrequest;
}
catch(exception) {
// OK, just carry on looking
}
}
// if we got here we didn’t find any matches
throw new Error("Cannot create an XMLHttpRequest");
}
}
